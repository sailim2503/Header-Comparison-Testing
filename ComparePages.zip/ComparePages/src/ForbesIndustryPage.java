import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ForbesIndustryPage {
public WebDriver driver,driver1;
File file=new File("C:\\Users\\saili.m\\Desktop\\Testing.xlsx");	

	String baseUrl1 = "https://www.forbes.com/";
	String baseUrl2="https://www.forbes.com/advisor/";
	String arr1[]=new String[30];
	String arr2[]=new String[30];
	
	String list1;
	String list2;
  @BeforeTest
	public void beforeTest() {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\saili.m\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver1=new ChromeDriver();
		driver.get(baseUrl1);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver1.get(baseUrl2);
		driver1.manage().window().maximize();
		driver1.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  }	
	

 
	
  @Test(priority=0)
  
  public void OnHoverBillionaries() throws IOException, InvalidFormatException, InterruptedException {
	  
	  String billionarie;
	 /* FileInputStream fis=new FileInputStream(file);
	  	  //Reading data from excel file
	   	  
	  XSSFWorkbook workbook=new XSSFWorkbook(fis);
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  Sheet sh=workbook.getSheet("Sheet1");
	  	  
	  Row r=sh.getRow(1);
	  if(r==null) 
	      r=sh.createRow(1);
   */
  	 	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[1]/a"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  System.out.println("List of Elements for Billionaries");
	  List<WebElement> list=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[1]/div[2]/ul"));
      for(WebElement li:list) {
    	  list1=li.getText();
    	  System.out.println(list1);
      driver.manage().window().wait(200);	  
    		//  Cell cell=r.createCell(0);
    		//  cell.setCellValue(billionarie);
    	  
    	  Actions action1=new Actions(driver1);
    	  WebElement menuOption1=driver1.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[1]/a"));
    	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
    	  action.moveToElement(menuOption).build().perform();
    	  System.out.println("List of Elements for Billionaries");
    	  List<WebElement> listnew=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[1]/div[2]/ul"));
          for(WebElement lo:listnew) {
        	  list2=lo.getText();
        	  System.out.println(list2);	  
    	  
      }
      }
      
     // fis.close();
	 // FileOutputStream fos=new FileOutputStream(file);
	 // workbook.write(fos);
	 // fos.close();
	  }

  
 @Test(priority=1)
  public void OnHoverInnovation() throws IOException {
	  String innovation;
	 
	  FileInputStream fis=new FileInputStream(file);
	  XSSFWorkbook workbook=new XSSFWorkbook(fis);
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  Sheet sh=workbook.getSheet("Sheet1");
	  
	  
	  Row r=sh.getRow(3);
	  if(r==null) 
	      r=sh.createRow(3);
	  
	  
	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[2]/a"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  System.out.println("List of Elements for Innovation");
	  List<WebElement> list=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[2]/div[2]/ul"));
      for(WebElement li:list) {
    	  innovation=li.getText();
    	  System.out.println(li.getText());
    	  Cell cell=r.createCell(0);
    	  cell.setCellValue(innovation);
      }
      fis.close();
	  FileOutputStream fos=new FileOutputStream(file);
	  workbook.write(fos);
	  fos.close();
	  }
/*
 @Test(priority=2)
  public void OnHoverLeaership() throws IOException {
	 String leadership;
	 File file=new File("C:\\Users\\saili.m\\Desktop\\Testing.xlsx");
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  //Reading data from excel file
	  FileInputStream fis=new FileInputStream(file);
	  
	  
	  XSSFWorkbook workbook=new XSSFWorkbook(fis);
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  Sheet sh=workbook.getSheet("Sheet1");
	  
	  
	  Row r=sh.getRow(5);
	  if(r==null) 
	      r=sh.createRow(5);
	 
	 
	 
	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[3]/a"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  System.out.println("List of Elements for Leadership");
	  List<WebElement> list=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[3]/div[2]/ul"));
      for(WebElement li:list) {
    	  leadership=li.getText();
    	  System.out.println(li.getText());
    	  Cell cell=r.createCell(0);
    	  cell.setCellValue(leadership);
      }
      
      fis.close();
	  FileOutputStream fos=new FileOutputStream(file);
	  workbook.write(fos);
	  fos.close();
	  }

   @Test(priority=3)
  public void OnHoverMoney() throws IOException {
	   String money;
	   		  //Reading data from excel file
		  FileInputStream fis=new FileInputStream(file);
		  
		  
		  XSSFWorkbook workbook=new XSSFWorkbook(fis);
		  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
		  Sheet sh=workbook.getSheet("Sheet1");
		  
		  
		  Row r=sh.getRow(7);
		  if(r==null) 
		      r=sh.createRow(7);
	   	   
	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[4]/a"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  System.out.println("List of Elements for Money");
	  List<WebElement> list=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[4]/div[2]/ul"));
      for(WebElement li:list) {
    	  money=li.getText();
    	  System.out.println(li.getText());
    	  Cell cell=r.createCell(0);
    	  cell.setCellValue(money);
      }
      fis.close();
	  FileOutputStream fos=new FileOutputStream(file);
	  workbook.write(fos);
	  fos.close();
	  }
  
  @Test(priority=4)
  public void OnHoverConsumer() throws IOException {
	  String consumer;
	  
	  FileInputStream fis=new FileInputStream(file);
	  
	  
	  XSSFWorkbook workbook=new XSSFWorkbook(fis);
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  Sheet sh=workbook.getSheet("Sheet1");
	  
	  
	  Row r=sh.getRow(9);
	  if(r==null) 
	      r=sh.createRow(9);
	  
	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[5]/a"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  System.out.println("List of Elements for Consumer");
	  List<WebElement> list=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[5]/div[2]/ul"));
      for(WebElement li:list) {
    	  consumer=li.getText();
    	  System.out.println(li.getText());
    	  Cell cell=r.createCell(0);
    	  cell.setCellValue(consumer);
      }
      fis.close();
	  FileOutputStream fos=new FileOutputStream(file);
	  workbook.write(fos);
	  fos.close();
	  }
  
  @Test(priority=5)
  public void OnHoverIndustry() throws IOException {
	  String industry;
	  
	  FileInputStream fis=new FileInputStream(file);
	  
	  
	  XSSFWorkbook workbook=new XSSFWorkbook(fis);
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  Sheet sh=workbook.getSheet("Sheet1");
	  
	  
	  Row r=sh.getRow(11);
	  if(r==null) 
	      r=sh.createRow(11);
	  
	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[6]/a"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  System.out.println("List of Elements for Industry");
	  List<WebElement> list=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[6]/div[2]/ul"));
      for(WebElement li:list) {
    	  industry=li.getText();
    	  System.out.println(li.getText());
    	  Cell cell=r.createCell(0);
    	  cell.setCellValue(industry);
      }
      fis.close();
	  FileOutputStream fos=new FileOutputStream(file);
	  workbook.write(fos);
	  fos.close();
	  }
  @Test(priority=6)
  public void OnHoverLifestyle() throws IOException {
	  String lifestyle;
	  
	  FileInputStream fis=new FileInputStream(file);
	  
	  
	  XSSFWorkbook workbook=new XSSFWorkbook(fis);
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  Sheet sh=workbook.getSheet("Sheet1");
	  
	  
	  Row r=sh.getRow(13);
	  if(r==null) 
	      r=sh.createRow(13);
	  
	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[7]/a"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  System.out.println("List of Elements for Lifestyle");
	  List<WebElement> list=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[7]/div[2]/ul"));
      for(WebElement li:list) {
    	  lifestyle=li.getText();
    	  System.out.println(li.getText());
    	  Cell cell=r.createCell(0);
    	  cell.setCellValue(lifestyle);
      }
      fis.close();
	  FileOutputStream fos=new FileOutputStream(file);
	  workbook.write(fos);
	  fos.close();
	  }
  @Test(priority=7)
  public void OnHoverBrandVoice() throws IOException {
	  String brandvoice;
	  
	  FileInputStream fis=new FileInputStream(file);
	  
	  
	  XSSFWorkbook workbook=new XSSFWorkbook(fis);
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  Sheet sh=workbook.getSheet("Sheet1");
	  
	  
	  Row r=sh.getRow(15);
	  if(r==null) 
	      r=sh.createRow(15);
	  
	  
	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[8]/span"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  System.out.println("List of Elements for BrandVoice");
	  List<WebElement> list=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[8]/div[2]/ul"));
      for(WebElement li:list) {
    	  brandvoice=li.getText();
    	  System.out.println(li.getText());
    	  Cell cell=r.createCell(0);
    	  cell.setCellValue(brandvoice);
      }
      fis.close();
	  FileOutputStream fos=new FileOutputStream(file);
	  workbook.write(fos);
	  fos.close();
      
	  }
  
  @Test(priority=8)
  public void OnHoverLists() throws IOException {
	  String lists;
	 
	  FileInputStream fis=new FileInputStream(file);
	  
	  
	  XSSFWorkbook workbook=new XSSFWorkbook(fis);
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  Sheet sh=workbook.getSheet("Sheet1");
	  
	  
	  Row r=sh.getRow(17);
	  if(r==null) 
	      r=sh.createRow(17);
	  
	  
	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[9]/a"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  lists="No List of Elements fpund for Lists";
	 Cell cell=r.createCell(0);
	 cell.setCellValue(lists);
	  }
  
  @Test(priority=9)
  public void OnHoverAdvisor() throws IOException {
	  String advisor;
	  
	  FileInputStream fis=new FileInputStream(file);
	  
	  
	  XSSFWorkbook workbook=new XSSFWorkbook(fis);
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  Sheet sh=workbook.getSheet("Sheet1");
	  
	  
	  Row r=sh.getRow(19);
	  if(r==null) 
	      r=sh.createRow(19);
	  
	  
	  
	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[10]/a"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  System.out.println("List of Elements for Advisor");
	  List<WebElement> list=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[10]/div[2]/ul"));
      for(WebElement li:list) {
    	  advisor=li.getText();
    	  System.out.println(li.getText());
    	  Cell cell=r.createCell(0);
    	  cell.setCellValue(advisor);
      }
      fis.close();
	  FileOutputStream fos=new FileOutputStream(file);
	  workbook.write(fos);
	  fos.close();
	  }
  @Test(priority=10)
  public void OnHoverFeatured() throws IOException {
	  String featured;
	  
	  FileInputStream fis=new FileInputStream(file);
	  XSSFWorkbook workbook=new XSSFWorkbook(fis);
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  Sheet sh=workbook.getSheet("Sheet1");
	  
	  
	  Row r=sh.getRow(21);
	  if(r==null) 
	      r=sh.createRow(21);
	  	  
	  Actions action=new Actions(driver);
	  WebElement menuOption=driver.findElement(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[11]/span"));
	  driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
	  action.moveToElement(menuOption).build().perform();
	  System.out.println("List of Elements for Featured");
	  List<WebElement> list=driver.findElements(By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[11]/div[2]/ul"));
      for(WebElement li:list) {
    	  featured=li.getText();
          System.out.println(li.getText());
          Cell cell=r.createCell(0);
          cell.setCellValue(featured);
          
      }
      fis.close();
	  FileOutputStream fos=new FileOutputStream(file);
	  workbook.write(fos);
	  fos.close();
	  
  
  } 
*/
  
  
  @AfterTest
  public void afterTest() {
	 driver.close();
	 driver1.close();
  }
}

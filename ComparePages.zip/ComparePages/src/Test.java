import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.ProfilesIni;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import net.jsourcerer.webdriver.jserrorcollector.JavaScriptError;

public class Test {

    public static WebDriver wbdv = null;
    public static EventFiringWebDriver driver=null;

    @BeforeClass
    public static void setUp() throws IOException {
        System.setProperty("webdriver.firefox.bin","C:\\Users\\saili.m\\Downloads\\selenium-firefox-driver-2.4.0.jar");
        try {
            ProfilesIni allProfiles = new ProfilesIni();
            FirefoxProfile profile = allProfiles.getProfile("default");
            profile.setAcceptUntrustedCertificates(true);
            profile.setAssumeUntrustedCertificateIssuer(false);
            wbdv = new FirefoxDriver();
            driver = new EventFiringWebDriver(wbdv);
        } catch(Throwable t) {
            System.out.println(t);
        }

        driver.get("http://www.example.com");
    }

    @AfterClass
    public static void tearDown() {
        List<JavaScriptError> jsErrors = JavaScriptError.readErrors(driver);
        System.out.println("###start displaying errors");
        for(int i = 0; i < jsErrors.size(); i++)
        {
            System.out.println(jsErrors.get(i).getErrorMessage());
            System.out.println(jsErrors.get(i).getLineNumber());
            System.out.println(jsErrors.get(i).getSourceName());
        }
        System.out.println("###start displaying errors");
        driver.close(); driver.quit();
    }
}
package Test;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ForbesActionClass {
 static WebElement element;
 static By f1=By.xpath("/html/body/div[1]/header/nav/div[2]/ul/li[10]/a");
 static By h1=By.className("header__channels");
 static By h2=By.className("menu");
 static By h3=By.className("header__subnav");
 static By h4=By.className("header__section header__hoverable");
 static ArrayList<String> headers1=new ArrayList<String>();
 static ArrayList<String> headers2=new ArrayList<String>();
 static ArrayList<String> subMenu1=new ArrayList<String>();
 static ArrayList<String> subMenu2=new ArrayList<String>();
 public static WebElement navigateToAdvisor(WebDriver driver) {
	  element=driver.findElement(f1);
	 return element;
 }
 public static void getForbesPrimaryHeader(WebDriver driver) throws InterruptedException {
	 List<WebElement> list1=driver.findElements(h1);
	 for(int i=0;i<list1.size();i++) {
		headers1.add(list1.get(i).getText());
	 }
	 Thread.sleep(20);
	 List<WebElement> list2=((WebDriver) headers1).findElements(h4);
	 System.out.println(list2.size());
	 for(int i=0;i<list2.size();i++) {
		subMenu1.add(list2.get(i).getText()); 
	 }
	 System.out.println(subMenu1);
	 System.out.println("=================================================");
 }
 public static void getAdvisorPrimaryHeader(WebDriver driver) {
	 List<WebElement> list1=driver.findElements(h2);
	 for(int i=0;i<list1.size();i++) {
		 headers2.add(list1.get(i).getText());
	 	 
	 }
	 List<WebElement> list2=driver.findElements(h3);
	 for(int i=0;i<list2.size();i++) {
		subMenu2.add(list2.get(i).getText()); 
	 }
	 System.out.println(subMenu2);
	 System.out.println("=================================================");
 }
 public static void compareHeaders(WebDriver driver) {
	 if(headers1.size()==headers2.size()) {
		 if(!(headers1.equals(headers2))) {
			 headers1.removeAll(headers2);
			 System.out.println(headers1);
		 }
		 else
			 System.out.println("Success!!!Match Found");
	 }
 }
 
}

package Test;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ForbesObject {
static WebDriver driver;

public static void main(String args[]) {
	System.setProperty("webdriver.chrome.driver","C:\\Users\\saili.m\\chromedriver_win32\\chromedriver.exe");
    driver = new ChromeDriver();
	driver.get("https://www.forbes.com/#63a731ec2254");
	driver.manage().window().maximize();
	
	try {
		getForbesHeaders();
		clickAdvisor();
		getAdvisorHeader();
		Compare();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

    
	

public static void clickAdvisor() throws InterruptedException {
	
	ForbesActionClass.navigateToAdvisor(driver).click();
	
}
public static void getForbesHeaders() throws InterruptedException {
	
	ForbesActionClass.getForbesPrimaryHeader(driver);
	
}
public static void getAdvisorHeader() {
	
	ForbesActionClass.getAdvisorPrimaryHeader(driver);
}
public static void Compare() {
	ForbesActionClass.compareHeaders(driver);
}



}

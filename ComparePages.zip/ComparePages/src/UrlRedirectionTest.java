import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class UrlRedirectionTest {
	public WebDriver driver;
	
	
	
  @Test
  public void f() throws IOException, InterruptedException {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\saili.m\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		FileInputStream fis = new FileInputStream("C:\\Users\\saili.m\\Desktop\\Advisor URLs (via sitemap).xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		 XSSFSheet sheet = workbook.getSheet("Sheet4");
		 for(int i=1;i<6;i++) {
		 Row row = sheet.getRow(i);
		 Cell cell = row.getCell(0);
		 //System.out.println(cell);
		 String str1=sheet.getRow(i).getCell(0).getStringCellValue(); 
		 String str2=sheet.getRow(i).getCell(1).getStringCellValue();
		// System.out.println(str1 +"*******");
		// System.out.println(str2 +"*******");
         driver.get(str1);
         String s=driver.getTitle();
         //to check for 404 page not found error
         if(s.equalsIgnoreCase("404")) {
        	 System.out.println("404 error found for : "+str1);
        	 
         }
         Thread.sleep(5000);
         //driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
        //to check given urls are redirecting to expected urls
         if(driver.getCurrentUrl().equals(str2)) 
        	 System.out.println("Success!"+str1+" is redirecting to expected url");
         
         else
        	 System.out.println("Error!"+str1+" is not redirecting to expected url");
                          
         driver.manage().window().maximize();
         driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		 }
	  driver.close();
  }
}
